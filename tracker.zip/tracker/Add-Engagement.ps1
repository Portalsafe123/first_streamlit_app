﻿$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

$path = Join-Path $PSScriptRoot "Audit_Tracker.xlsx"
if (-not (Test-Path $path)) {
    Write-Host "Audit_Tracker.xlsx is folder mein nahi mili."
    exit 1
}

function Ole([int]$r, [int]$g, [int]$b) {
    return [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb($r, $g, $b))
}

function Read-Named($wb, [string]$name) {
    $range = $wb.Names.Item($name).RefersToRange
    return $range.Value2
}

function Clear-Named($wb, [string]$name) {
    $wb.Names.Item($name).RefersToRange.ClearContents() | Out-Null
}

function TextOf($value) {
    if ($null -eq $value) { return "" }
    return ([string]$value).Trim()
}

$excel = $null
$wb = $null
$keepOpen = $false

try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.ScreenUpdating = $false
    $wb = $excel.Workbooks.Open($path)

    $project = TextOf (Read-Named $wb "In_Project")
    $unique = TextOf (Read-Named $wb "In_Unique")
    $client = TextOf (Read-Named $wb "In_Client")
    $primary = TextOf (Read-Named $wb "In_Primary")
    $msg = $wb.Names.Item("In_Message").RefersToRange

    if ($project -eq "" -or $client -eq "" -or $primary -eq "") {
        $msg.Value2 = "Project Name, Client Legal Entity, aur Primary Analyst zaroori hain. Add nahi hua."
        $msg.Interior.Color = (Ole 255 199 206)
        $wb.Save()
        $keepOpen = $true
        $excel.Visible = $true
        $excel.UserControl = $true
        $wb.Worksheets.Item("Add Engagement").Activate()
        Write-Host "Zaroori fields khali hain."
        return
    }

    $tr = $wb.Worksheets.Item("Project Tracker")
    $col = @{}
    for ($c = 1; $c -le 60; $c++) {
        $header = TextOf $tr.Cells.Item(2, $c).Value2
        if ($header -ne "") { $col[$header] = $c }
    }

    $next = 0
    $count = 0
    for ($r = 3; $r -le 302; $r++) {
        $existingName = TextOf $tr.Cells.Item($r, [int]$col["Project / Engagement Name"]).Value2
        $existingClient = TextOf $tr.Cells.Item($r, [int]$col["Client Legal Entity"]).Value2
        $existingId = TextOf $tr.Cells.Item($r, [int]$col["Unique Identifier"]).Value2
        if ($existingName -eq "") {
            if ($next -eq 0) { $next = $r }
            continue
        }
        $count++
        if ($existingName.ToLower() -eq $project.ToLower() -and $existingClient.ToLower() -eq $client.ToLower()) {
            $msg.Value2 = "Yeh project aur client pehle se tracker mein hai. Add nahi hua."
            $msg.Interior.Color = (Ole 255 199 206)
            $wb.Save()
            $keepOpen = $true
            $excel.Visible = $true
            $excel.UserControl = $true
            $wb.Worksheets.Item("Add Engagement").Activate()
            Write-Host "Duplicate project."
            return
        }
        if ($unique -ne "" -and $existingId.ToLower() -eq $unique.ToLower()) {
            $msg.Value2 = "Yeh Unique Identifier pehle se hai: $unique. Add nahi hua."
            $msg.Interior.Color = (Ole 255 199 206)
            $wb.Save()
            $keepOpen = $true
            $excel.Visible = $true
            $excel.UserControl = $true
            $wb.Worksheets.Item("Add Engagement").Activate()
            Write-Host "Duplicate id."
            return
        }
    }

    if ($next -eq 0) {
        $msg.Value2 = "Tracker mein 300 lines full hain. Add nahi hua."
        $msg.Interior.Color = (Ole 255 199 206)
        $wb.Save()
        $keepOpen = $true
        $excel.Visible = $true
        $excel.UserControl = $true
        Write-Host "Tracker full."
        return
    }

    if ($unique -eq "") { $unique = "$($count + 1)$project" }

    function Write-Cell([string]$header, $value) {
        if ($null -eq $value) { return }
        if ((TextOf $value) -eq "") { return }
        $cell = $tr.Cells.Item($next, [int]$col[$header])
        if ($value -is [double] -or $value -is [int] -or $value -is [decimal]) {
            $cell.Formula = ([double]$value).ToString([System.Globalization.CultureInfo]::InvariantCulture)
        } else {
            $cell.Value2 = [string]$value
        }
        $cell.Interior.Color = (Ole 255 249 230)
    }

    Write-Cell "Project / Engagement Name" $project
    Write-Cell "Unique Identifier" $unique
    Write-Cell "Client Legal Entity" $client
    Write-Cell "Primary Analyst" $primary
    Write-Cell "Project Type" (TextOf (Read-Named $wb "In_ProjectType"))
    Write-Cell "Engagement Job Code" (TextOf (Read-Named $wb "In_JobCode"))
    Write-Cell "Engagement Period" (TextOf (Read-Named $wb "In_Period"))
    Write-Cell "ERP Platform" (TextOf (Read-Named $wb "In_ERP"))
    Write-Cell "Business Area KPI Distribution" (TextOf (Read-Named $wb "In_BusinessArea"))
    Write-Cell "Engagement Type (New/Recurring)" (TextOf (Read-Named $wb "In_EngType"))
    Write-Cell "Secondary Analyst" (TextOf (Read-Named $wb "In_Secondary"))
    Write-Cell "CI Delivery Lead" (TextOf (Read-Named $wb "In_CILead"))
    Write-Cell "Engagement Manager" (TextOf (Read-Named $wb "In_Manager"))
    Write-Cell "Manager Email" (TextOf (Read-Named $wb "In_ManagerEmail"))
    Write-Cell "Engagement Partner" (TextOf (Read-Named $wb "In_Partner"))
    Write-Cell "Partner Email" (TextOf (Read-Named $wb "In_PartnerEmail"))
    Write-Cell "Engagement Team POC" (TextOf (Read-Named $wb "In_POC"))
    Write-Cell "POC Email" (TextOf (Read-Named $wb "In_POCEmail"))

    $target = Read-Named $wb "In_Target"
    $request = Read-Named $wb "In_Request"
    if ($target -is [double]) { Write-Cell "Target Delivery Date" $target }
    if ($request -is [double]) { Write-Cell "Request Initiation Date" $request }

    $statusCell = $tr.Cells.Item($next, [int]$col["Overall Project Status"])
    $statusCell.Value2 = "WIP"
    $statusCell.Interior.Color = (Ole 255 249 230)

    $excel.Calculate()

    $form = $wb.Worksheets.Item("Add Engagement")
    $logRow = 37
    while ((TextOf $form.Cells.Item($logRow, 1).Value2) -ne "") { $logRow++ }
    $form.Cells.Item($logRow, 1).Value2 = (Get-Date).ToString("dd-MMM-yyyy HH:mm")
    $form.Cells.Item($logRow, 2).Value2 = $project
    $form.Cells.Item($logRow, 3).Value2 = $unique
    $form.Cells.Item($logRow, 4).Value2 = $client
    $form.Cells.Item($logRow, 5).Value2 = $primary
    $form.Cells.Item($logRow, 6).Value2 = "Added"

    foreach ($name in @(
            "In_Project", "In_Unique", "In_Client", "In_Primary", "In_ProjectType", "In_JobCode",
            "In_Period", "In_ERP", "In_BusinessArea", "In_EngType", "In_Secondary", "In_CILead",
            "In_Manager", "In_ManagerEmail", "In_Partner", "In_PartnerEmail", "In_POC", "In_POCEmail",
            "In_Target", "In_Request"
        )) {
        Clear-Named $wb $name
    }

    $msg.Value2 = "Add ho gaya. Unique Identifier: $unique. Project Tracker ki line $next dekho. Office, POC, manager aur step owners tab aayenge jab client Legal Entity Details mein milega."
    $msg.Interior.Color = (Ole 198 239 206)

    $wb.Save()
    $tr.Activate()
    $tr.Cells.Item($next, 2).Select() | Out-Null
    $excel.Visible = $true
    $excel.UserControl = $true
    $keepOpen = $true
    Write-Host "Added $unique on row $next"
}
catch {
    Write-Host "Add nahi ho paya. Excel mein Audit_Tracker.xlsx band karke dubara try karo."
    Write-Host $_.Exception.Message
    if ($wb -ne $null) {
        try { $wb.Close($false) } catch {}
        $wb = $null
    }
    if ($excel -ne $null) {
        try { $excel.Quit() } catch {}
    }
    exit 1
}
finally {
    if (-not $keepOpen) {
        try { if ($wb -ne $null) { $wb.Close($false) } } catch {}
        try { if ($excel -ne $null) { $excel.Quit() } } catch {}
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
