@echo off
cd /d "%~dp0"
if not exist "%~dp0Inbox" mkdir "%~dp0Inbox"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Import-ET.ps1" %*
echo.
pause
