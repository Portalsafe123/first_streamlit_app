﻿param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$Path
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

$root = $PSScriptRoot
$trackerPath = Join-Path $root "Audit_Tracker.xlsx"
$inbox = Join-Path $root "Inbox"
$processed = Join-Path $inbox "Processed"
New-Item -ItemType Directory -Force -Path $inbox, $processed | Out-Null

if (-not (Test-Path $trackerPath)) {
    Write-Host "Audit_Tracker.xlsx nahi mili."
    exit 1
}

function Ole([int]$r, [int]$g, [int]$b) {
    return [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb($r, $g, $b))
}

function Normalize([string]$s) {
    if ([string]::IsNullOrWhiteSpace($s)) { return "" }
    $s = $s -replace '\([^)]*\)', ' '
    $s = $s.ToLower()
    $s = $s -replace '_', ' '
    $s = $s -replace '[^a-z0-9/ ]', ' '
    $s = ($s -replace '\s+', ' ').Trim()
    return $s
}

function TextOf($value) {
    if ($null -eq $value) { return "" }
    return ([string]$value).Trim()
}

function Get-SheetMap($ws) {
    $map = @{}
    $last = [Math]::Min(80, [Math]::Max(40, $ws.UsedRange.Rows.Count))
    for ($r = 1; $r -le $last; $r++) {
        $a = TextOf $ws.Cells.Item($r, 1).Value2
        $b = TextOf $ws.Cells.Item($r, 2).Value2
        if ($a -eq "") { continue }
        $hits = [regex]::Matches($a, ":\s+")
        if ($hits.Count -gt 0) {
            $hit = $hits[$hits.Count - 1]
            $label = $a.Substring(0, $hit.Index)
            $value = $a.Substring($hit.Index + $hit.Length).Trim()
            if ($value -eq "" -and $b -ne "") { $value = $b }
        } elseif ($a.IndexOf(":") -gt 0) {
            $idx = $a.IndexOf(":")
            $label = $a.Substring(0, $idx)
            $value = $a.Substring($idx + 1).Trim()
            if ($value -eq "" -and $b -ne "") { $value = $b }
        } elseif ($b -ne "") {
            $label = $a
            $value = $b
        } else {
            continue
        }
        $key = Normalize $label
        if ($key -ne "" -and -not $map.ContainsKey($key)) { $map[$key] = $value }
    }
    return $map
}

$aliases = @{
    Client = @("client legal name", "client name", "legal entity name")
    Project = @("engagement name/ project name", "engagement name / project name", "engagement name", "project name")
    JobCode = @("project code", "engagement job code", "job code")
    POC = @("engagement point of contact", "point of contact")
    POCEmail = @("poc email id", "poc email")
    Partner = @("partner name")
    PartnerEmail = @("partner email id", "partner email")
    Manager = @("manager name")
    ManagerEmail = @("manager email id", "manager email")
    ProjectType = @("type of audit")
    PublicPrivate = @("public or private entity", "public or private")
    Period = @("engagement period of the datasets", "engagement period")
    Service = @("service line")
    Industry = @("industry/sector", "industry sector", "industry")
    ERP = @("client erp", "erp platform")
    DataVolume = @("expected data volume", "data volume")
    BusinessArea = @("business areas to be tested", "business area")
    ACMDate = @("acm date/archival date", "acm date", "archival date")
    EngType = @("new or recurring request", "new or recurring", "engagement type")
}

function Get-Field($map, [string]$name) {
    $norms = @()
    foreach ($alias in $aliases[$name]) { $norms += (Normalize $alias) }
    foreach ($n in $norms) {
        if ($map.ContainsKey($n) -and $map[$n]) { return [string]$map[$n] }
    }
    $norms = $norms | Sort-Object Length -Descending
    foreach ($n in $norms) {
        if ($n.Length -lt 4) { continue }
        foreach ($k in @($map.Keys)) {
            if ($k.StartsWith($n) -or $n.StartsWith($k)) {
                if ($map[$k]) { return [string]$map[$k] }
            }
        }
    }
    return ""
}

function Parse-DateOrNull([string]$text) {
    if ([string]::IsNullOrWhiteSpace($text)) { return $null }
    $styles = [System.Globalization.DateTimeStyles]::AllowWhiteSpaces
    foreach ($name in @("en-IN", "en-GB", "en-US")) {
        $culture = [System.Globalization.CultureInfo]::GetCultureInfo($name)
        $parsed = [datetime]::MinValue
        if ([datetime]::TryParse($text, $culture, $styles, [ref]$parsed)) { return $parsed }
    }
    return $null
}

function Map-EngType([string]$text) {
    $t = $text.ToLower()
    if ($t -match "recurr") { return "Recurring" }
    if ($t -match "new") { return "New" }
    return ""
}

function Get-HeaderMap($ws) {
    $map = @{}
    for ($c = 1; $c -le 80; $c++) {
        $h = TextOf $ws.Cells.Item(2, $c).Value2
        if ($h -ne "") { $map[$h] = $c }
    }
    return $map
}

function Ensure-ExtraColumns($tr) {
    $map = Get-HeaderMap $tr
    $last = ($map.Values | Measure-Object -Maximum).Maximum
    $gold = Ole 255 192 0
    foreach ($name in @("Public or Private", "ACM / Archival Date")) {
        if (-not $map.ContainsKey($name)) {
            $last++
            $cell = $tr.Cells.Item(2, $last)
            $cell.Value2 = $name
            $cell.Font.Bold = $true
            $cell.Font.Color = (Ole 0 0 0)
            $cell.Font.Name = "Calibri"
            $cell.Interior.Color = $gold
            $cell.WrapText = $true
            $cell.HorizontalAlignment = -4108
            $tr.Columns.Item($last).ColumnWidth = 22
            if ($name -like "*Date*") {
                $tr.Range($tr.Cells.Item(3, $last), $tr.Cells.Item(302, $last)).NumberFormat = "DD-MMM-YYYY"
            }
            $map[$name] = $last
        }
    }
    if ($tr.AutoFilterMode) { $tr.AutoFilterMode = $false }
    $tr.Range($tr.Cells.Item(2, 1), $tr.Cells.Item(302, $last)).AutoFilter() | Out-Null
    return $map
}

function Write-Text($tr, $colMap, [int]$row, [string]$header, [string]$value) {
    if ([string]::IsNullOrWhiteSpace($value)) { return }
    if (-not $colMap.ContainsKey($header)) { return }
    $cell = $tr.Cells.Item($row, [int]$colMap[$header])
    $cell.Value2 = $value
    $cell.Font.Color = (Ole 0 0 0)
    $cell.Interior.Color = (Ole 255 249 230)
}

function Write-Date($tr, $colMap, [int]$row, [string]$header, $date) {
    if ($null -eq $date) { return }
    if (-not $colMap.ContainsKey($header)) { return }
    $cell = $tr.Cells.Item($row, [int]$colMap[$header])
    $serial = $date.ToOADate().ToString([System.Globalization.CultureInfo]::InvariantCulture)
    $cell.Formula = $serial
    $cell.NumberFormat = "DD-MMM-YYYY"
    $cell.Font.Color = (Ole 0 0 0)
    $cell.Interior.Color = (Ole 255 249 230)
}

function Upsert-Legal($legal, [string]$client, [string]$service, [string]$industry, [string]$poc, [string]$pocEmail, [string]$manager, [string]$managerEmail, [string]$partner, [string]$partnerEmail, [string]$continuing) {
    $target = 0
    for ($r = 2; $r -le 200; $r++) {
        $name = TextOf $legal.Cells.Item($r, 1).Value2
        if ($name -eq "") {
            if ($target -eq 0) { $target = $r }
            continue
        }
        if ($name.ToLower() -eq $client.ToLower()) { $target = $r; break }
    }
    if ($target -eq 0) { return }
    $existing = TextOf $legal.Cells.Item($target, 1).Value2
    $isNew = $existing -eq ""
    if ($isNew) { $legal.Cells.Item($target, 1).Value2 = $client }
    $pairs = @(
        @(2, $service),
        @(3, $industry),
        @(4, $poc),
        @(5, $pocEmail),
        @(6, $manager),
        @(7, $managerEmail),
        @(8, $partner),
        @(9, $partnerEmail),
        @(12, $continuing)
    )
    foreach ($pair in $pairs) {
        if ([string]::IsNullOrWhiteSpace($pair[1])) { continue }
        $current = TextOf $legal.Cells.Item($target, [int]$pair[0]).Value2
        if ($isNew -or $current -eq "") {
            $legal.Cells.Item($target, [int]$pair[0]).Value2 = [string]$pair[1]
        }
    }
}

$files = @()
if ($Path -and $Path.Count -gt 0) {
    foreach ($item in $Path) {
        if ([string]::IsNullOrWhiteSpace($item)) { continue }
        if (Test-Path -LiteralPath $item) { $files += (Resolve-Path -LiteralPath $item).Path }
    }
} else {
    $files = @(Get-ChildItem -Path $inbox -File | Where-Object { $_.Extension -match '^\.(xlsx|xlsm|xls)$' -and $_.Name -notlike '~$*' -and $_.Name -ne 'Audit_Tracker.xlsx' } | ForEach-Object { $_.FullName })
}

if ($files.Count -eq 0) {
    Write-Host "Koi ET file nahi mili."
    Write-Host "ET wali Excel ko is folder mein rakho: $inbox"
    Write-Host "Phir Import-ET.bat dubara chalao. Ya file ko Import-ET.bat par drop karo."
    Write-Host "Audit_Tracker.xlsx us waqt band honi chahiye."
    exit 1
}

$excel = $null
$wb = $null
try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.ScreenUpdating = $false
    $wb = $excel.Workbooks.Open($trackerPath)
    $tr = $wb.Worksheets.Item("Project Tracker")
    $legal = $wb.Worksheets.Item("Legal Entity Details")
    $colMap = Ensure-ExtraColumns $tr

    $how = $wb.Worksheets.Item("Kaise use karein")
    if ((TextOf $how.Range("C17").Value2) -notlike "*Import-ET*") {
        $how.Range("B17").Value2 = "10. ET file se"
        $how.Range("B17").Font.Bold = $true
        $how.Range("B17").VerticalAlignment = -4108
        $how.Range("B17").Interior.Color = (Ole 242 246 250)
        $how.Range("C17").Value2 = "ET wali Excel Inbox folder mein rakho, ya Import-ET.bat par drop karo. Audit_Tracker band hona chahiye. Project, client, code, partner, manager, POC, period aur ERP khud add ho jayenge. Primary Analyst baad mein bharo."
        $how.Range("C17").WrapText = $true
        $how.Rows.Item(17).RowHeight = 48
    }

    $added = 0
    $skipped = @()
    foreach ($file in $files) {
        if ((Split-Path $file -Leaf) -eq "Audit_Tracker.xlsx") { continue }
        $src = $null
        try {
            $src = $excel.Workbooks.Open($file, 0, $true)
            $best = $null
            $bestScore = 0
            foreach ($ws in $src.Worksheets) {
                $map = Get-SheetMap $ws
                $score = 0
                foreach ($key in @("Client", "Project", "Partner", "Manager", "JobCode")) {
                    if ((Get-Field $map $key) -ne "") { $score++ }
                }
                if ($score -gt $bestScore) { $bestScore = $score; $best = $map }
            }
            $client = ""
            $project = ""
            $job = ""
            $canAdd = $false
            if ($bestScore -lt 2 -or $null -eq $best) {
                $skipped += "$(Split-Path $file -Leaf): ET fields nahi mile"
            } else {
                $client = Get-Field $best "Client"
                $project = Get-Field $best "Project"
                $job = Get-Field $best "JobCode"
                if ($client -eq "" -or $project -eq "") {
                    $skipped += "$(Split-Path $file -Leaf): Client ya Project Name khali hai"
                } else {
                    $canAdd = $true
                }
            }
            if ($canAdd) {

            $duplicate = $false
            $next = 0
            $count = 0
            for ($r = 3; $r -le 302; $r++) {
                $existingProject = TextOf $tr.Cells.Item($r, [int]$colMap["Project / Engagement Name"]).Value2
                $existingClient = TextOf $tr.Cells.Item($r, [int]$colMap["Client Legal Entity"]).Value2
                $existingJob = TextOf $tr.Cells.Item($r, [int]$colMap["Engagement Job Code"]).Value2
                if ($existingProject -eq "") {
                    if ($next -eq 0) { $next = $r }
                    continue
                }
                $count++
                $sameProject = $existingProject.ToLower() -eq $project.ToLower() -and $existingClient.ToLower() -eq $client.ToLower()
                $sameJob = $job -ne "" -and $existingJob.ToLower() -eq $job.ToLower()
                if ($sameProject -or $sameJob) { $duplicate = $true }
            }
            if ($duplicate) {
                $skipped += "$(Split-Path $file -Leaf): pehle se tracker mein hai"
            } elseif ($next -eq 0) {
                $skipped += "$(Split-Path $file -Leaf): tracker full hai"
            } else {
            $engType = Map-EngType (Get-Field $best "EngType")
            $continuing = ""
            if ($engType -eq "New") { $continuing = "New" }
            if ($engType -eq "Recurring") { $continuing = "Continuing" }

            Upsert-Legal $legal $client (Get-Field $best "Service") (Get-Field $best "Industry") (Get-Field $best "POC") (Get-Field $best "POCEmail") (Get-Field $best "Manager") (Get-Field $best "ManagerEmail") (Get-Field $best "Partner") (Get-Field $best "PartnerEmail") $continuing

            $unique = "$($count + 1)$client"
            if ($unique.Length -gt 40) { $unique = $unique.Substring(0, 40) }

            Write-Text $tr $colMap $next "Project / Engagement Name" $project
            Write-Text $tr $colMap $next "Unique Identifier" $unique
            Write-Text $tr $colMap $next "Client Legal Entity" $client
            Write-Text $tr $colMap $next "Project Type" (Get-Field $best "ProjectType")
            Write-Text $tr $colMap $next "Engagement Job Code" $job
            Write-Text $tr $colMap $next "Engagement Period" (Get-Field $best "Period")
            Write-Text $tr $colMap $next "ERP Platform" (Get-Field $best "ERP")
            Write-Text $tr $colMap $next "Business Area KPI Distribution" (Get-Field $best "BusinessArea")
            Write-Text $tr $colMap $next "Engagement Type (New/Recurring)" $engType
            Write-Text $tr $colMap $next "Data Volume" (Get-Field $best "DataVolume")
            Write-Text $tr $colMap $next "Public or Private" (Get-Field $best "PublicPrivate")
            Write-Text $tr $colMap $next "Overall Project Status" "Yet to be picked"
            Write-Text $tr $colMap $next "Service line" (Get-Field $best "Service")
            Write-Text $tr $colMap $next "Industry / sector" (Get-Field $best "Industry")
            Write-Text $tr $colMap $next "Engagement Team POC" (Get-Field $best "POC")
            Write-Text $tr $colMap $next "POC Email" (Get-Field $best "POCEmail")
            Write-Text $tr $colMap $next "Engagement Manager" (Get-Field $best "Manager")
            Write-Text $tr $colMap $next "Manager Email" (Get-Field $best "ManagerEmail")
            Write-Text $tr $colMap $next "Engagement Partner" (Get-Field $best "Partner")
            Write-Text $tr $colMap $next "Partner Email" (Get-Field $best "PartnerEmail")
            Write-Text $tr $colMap $next "Continuing/New" $continuing
            Write-Date $tr $colMap $next "ACM / Archival Date" (Parse-DateOrNull (Get-Field $best "ACMDate"))

            $added++
            Write-Host "Add ho gaya: $project"
            }
            }
        }
        finally {
            if ($src -ne $null) {
                $src.Close($false)
                $src = $null
            }
        }

        $destName = "{0:yyyyMMdd-HHmmss}-{1}" -f (Get-Date), (Split-Path $file -Leaf)
        $dest = Join-Path $processed $destName
        try {
            Move-Item -LiteralPath $file -Destination $dest -Force
        } catch {
            Write-Host "File move nahi hui, par data add ho chuka hai: $file"
        }
    }

    $excel.Calculate()
    $wb.Save()
    $wb.Close($true)
    $wb = $null
    Write-Host ""
    Write-Host "Added: $added"
    foreach ($line in $skipped) { Write-Host $line }
    if ($added -gt 0) {
        Write-Host "Project Tracker kholo. Primary Analyst abhi khali hai, use bhar do. Step owners usi naam se ban jayenge."
    }
    if ($added -eq 0) { exit 1 }
}
catch {
    Write-Host "Import nahi ho paya. Audit_Tracker.xlsx band karke dubara try karo."
    Write-Host $_.Exception.Message
    exit 1
}
finally {
    try { if ($wb -ne $null) { $wb.Close($false) } } catch {}
    try { if ($excel -ne $null) { $excel.Quit() } } catch {}
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
