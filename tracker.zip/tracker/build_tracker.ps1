﻿param([switch]$Force)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

$outPath = Join-Path $PSScriptRoot "Audit_Tracker.xlsx"
$resultPath = Join-Path $PSScriptRoot "build_result.txt"

if ((Test-Path $outPath) -and -not $Force) {
    Write-Host "Audit_Tracker.xlsx already exists. Not overwriting. Run with -Force only if you want a new empty file."
    exit 1
}

function Ole([int]$r, [int]$g, [int]$b) {
    return [System.Drawing.ColorTranslator]::ToOle([System.Drawing.Color]::FromArgb($r, $g, $b))
}

$gold = Ole 255 192 0
$goldFont = Ole 0 0 0
$blue = Ole 47 84 150
$white = Ole 255 255 255
$navy = Ole 31 78 121
$greenFill = Ole 198 239 206
$greenFont = Ole 0 97 0
$wipFill = Ole 255 80 80
$dropFill = Ole 217 217 217
$dropFont = Ole 89 89 89
$dormFill = Ole 192 0 0
$pendingFill = Ole 255 230 153
$pendingFont = Ole 128 96 0
$inputFill = Ole 255 249 230
$formFill = Ole 255 242 204
$sectionFill = Ole 31 78 121
$okFill = Ole 226 239 218
$cardFill = Ole 242 246 250
$thin = 1
$xlCenter = -4108
$xlLeft = -4131
$xlCalcAuto = -4105

$excel = $null
$wb = $null
$saved = $false

try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.ScreenUpdating = $false

    $wb = $excel.Workbooks.Add()
    $excel.Calculation = $xlCalcAuto
    while ($wb.Worksheets.Count -gt 1) {
        $wb.Worksheets.Item($wb.Worksheets.Count).Delete()
    }

    $names = @(
        "Kaise use karein",
        "Add Engagement",
        "Project Tracker",
        "Summary",
        "Data Sanity",
        "Data Cleansing",
        "Data Upload",
        "KPI Execution",
        "Legal Entity Details",
        "Lists"
    )
    $wb.Worksheets.Item(1).Name = $names[0]
    for ($i = 1; $i -lt $names.Count; $i++) {
        $sheet = $wb.Worksheets.Add([Type]::Missing, $wb.Worksheets.Item($wb.Worksheets.Count))
        $sheet.Name = $names[$i]
    }

    function Sheet([string]$name) { return $wb.Worksheets.Item($name) }

    # ---------- Lists ----------
    $lists = Sheet "Lists"
    $listHeaders = @("Status", "Engagement Type", "Project Type", "Region", "Continuing/New", "Service line", "Delivery Lead", "Primary Analyst")
    for ($c = 0; $c -lt $listHeaders.Count; $c++) {
        $lists.Cells.Item(1, $c + 1).Value2 = $listHeaders[$c]
        $lists.Cells.Item(1, $c + 1).Font.Bold = $true
        $lists.Cells.Item(1, $c + 1).Interior.Color = $navy
        $lists.Cells.Item(1, $c + 1).Font.Color = $white
    }
    $statuses = @("Yet to be picked", "WIP", "Done", "Dormant", "Not Applicable", "On Hold", "Dropped")
    for ($i = 0; $i -lt $statuses.Count; $i++) { $lists.Cells.Item($i + 2, 1).Value2 = $statuses[$i] }
    $lists.Cells.Item(2, 2).Value2 = "New"
    $lists.Cells.Item(3, 2).Value2 = "Recurring"
    $lists.Cells.Item(2, 3).Value2 = "Stat"
    $lists.Cells.Item(3, 3).Value2 = "Review"
    $regions = @("North", "South", "East", "West")
    for ($i = 0; $i -lt $regions.Count; $i++) { $lists.Cells.Item($i + 2, 4).Value2 = $regions[$i] }
    $lists.Cells.Item(2, 5).Value2 = "New"
    $lists.Cells.Item(3, 5).Value2 = "Continuing"
    $services = @("Assurance", "Risk", "Tax", "Consulting")
    for ($i = 0; $i -lt $services.Count; $i++) { $lists.Cells.Item($i + 2, 6).Value2 = $services[$i] }
    $leads = @("Kashish Narang", "Dawood Khan", "Ishita Garg")
    for ($i = 0; $i -lt $leads.Count; $i++) { $lists.Cells.Item($i + 2, 7).Value2 = $leads[$i] }
    $analysts = @("Akhilesh", "Anchal", "Avinash", "Dawood", "Isha", "Ishita", "Kashish", "Pallavi", "Rahul")
    for ($i = 0; $i -lt $analysts.Count; $i++) { $lists.Cells.Item($i + 2, 8).Value2 = $analysts[$i] }
    $lists.Columns.AutoFit() | Out-Null

    $wb.Names.Add("StatusList", "=Lists!`$A`$2:`$A`$8") | Out-Null
    $wb.Names.Add("EngTypeList", "=Lists!`$B`$2:`$B`$3") | Out-Null
    $wb.Names.Add("ProjectTypeList", "=Lists!`$C`$2:`$C`$3") | Out-Null
    $wb.Names.Add("RegionList", "=Lists!`$D`$2:`$D`$5") | Out-Null
    $wb.Names.Add("ContList", "=Lists!`$E`$2:`$E`$3") | Out-Null
    $wb.Names.Add("ServiceList", "=Lists!`$F`$2:`$F`$5") | Out-Null
    $wb.Names.Add("DeliveryLeadList", "=Lists!`$G`$2:`$G`$4") | Out-Null
    $wb.Names.Add("AnalystList", "=Lists!`$H`$2:`$H`$10") | Out-Null

    # ---------- Legal Entity Details ----------
    $legal = Sheet "Legal Entity Details"
    $legalHeaders = @(
        "Legal Entity Name",
        "Service line",
        "Industry / sector",
        "ET - POC",
        "ET - POC email Id",
        "Manager",
        "Manager email Id",
        "ET - Partner",
        "ET Partner - email ID",
        "Office location",
        "Region",
        "Continuing/New"
    )
    for ($c = 0; $c -lt $legalHeaders.Count; $c++) {
        $cell = $legal.Cells.Item(1, $c + 1)
        $cell.Value2 = $legalHeaders[$c]
        $cell.Font.Bold = $true
        $cell.Font.Color = $goldFont
        $cell.Interior.Color = $gold
        $cell.WrapText = $true
        $cell.HorizontalAlignment = $xlCenter
        $cell.VerticalAlignment = $xlCenter
    }
    $legal.Rows.Item(1).RowHeight = 30
    $exampleLegal = @(
        "EXAMPLE Client Pvt Ltd",
        "Assurance",
        "Manufacturing",
        "Priya Shah",
        "priya.shah@example.com",
        "Rohan Mehta",
        "rohan.mehta@example.com",
        "Neha Kapoor",
        "neha.kapoor@example.com",
        "Gurgaon",
        "North",
        "New"
    )
    for ($c = 0; $c -lt $exampleLegal.Count; $c++) {
        $legal.Cells.Item(2, $c + 1).Value2 = $exampleLegal[$c]
    }
    $legal.Range("A1:L200").Borders.LineStyle = $thin
    $legal.Range("B2:B200").Validation.Add(3, 1, 1, "=ServiceList") | Out-Null
    $legal.Range("B2:B200").Validation.InCellDropdown = $true
    $legal.Range("B2:B200").Validation.IgnoreBlank = $true
    $legal.Range("K2:K200").Validation.Add(3, 1, 1, "=RegionList") | Out-Null
    $legal.Range("K2:K200").Validation.InCellDropdown = $true
    $legal.Range("K2:K200").Validation.IgnoreBlank = $true
    $legal.Range("L2:L200").Validation.Add(3, 1, 1, "=ContList") | Out-Null
    $legal.Range("L2:L200").Validation.InCellDropdown = $true
    $legal.Range("L2:L200").Validation.IgnoreBlank = $true
    $legal.Range("A1:L200").AutoFilter() | Out-Null
    $legal.Application.ActiveWindow.SplitRow = 1
    $legal.Activate()
    $legal.Range("A2").Select() | Out-Null
    $excel.ActiveWindow.FreezePanes = $true
    $widthsLegal = @(36, 16, 28, 20, 32, 20, 32, 20, 32, 18, 12, 18)
    for ($c = 0; $c -lt $widthsLegal.Count; $c++) { $legal.Columns.Item($c + 1).ColumnWidth = $widthsLegal[$c] }
    $legal.Range("N1").Value2 = "Nayi client turant neeche likho. Naam, Project Tracker ke Client Legal Entity se letter-to-letter match hona chahiye. Example row clear kar sakte ho."
    $legal.Range("N1:R3").Merge() | Out-Null
    $legal.Range("N1").WrapText = $true
    $legal.Range("N1").VerticalAlignment = $xlCenter
    $legal.Range("N1").Font.Italic = $true
    $legal.Columns.Item(14).ColumnWidth = 18

    # ---------- Project Tracker ----------
    $tr = Sheet "Project Tracker"
    $headers = @(
        "Sno",
        "Project / Engagement Name",
        "Unique Identifier",
        "Client Legal Entity",
        "Project Type",
        "Engagement Job Code",
        "Office location",
        "Region",
        "Service line",
        "Industry / sector",
        "Engagement Period",
        "ERP Platform",
        "Business Area KPI Distribution",
        "Engagement Team POC",
        "POC Email",
        "Engagement Manager",
        "Manager Email",
        "Engagement Partner",
        "Partner Email",
        "CI Delivery Lead",
        "Primary Analyst",
        "Secondary Analyst",
        "Overall Project Status",
        "Engagement Type (New/Recurring)",
        "Step 1 - Data Validation Owner",
        "Step 1 - Data Validation Status",
        "Step 2 - Data Cleansing Owner",
        "Step 2 - Data Cleansing Status",
        "Step 3 - Data Upload Owner",
        "Step 3 - Data Upload Status",
        "Step 4 - KPI Execution Owner",
        "Step 4 - KPI Execution Status",
        "KPIs Delivered",
        "Target Delivery Date",
        "Request Initiation Date",
        "CI Acknowledged",
        "Initial Delivery Date",
        "Final Delivery Date",
        "Dashboard Delivered",
        "Business Areas Count",
        "Data Volume",
        "Files Processed",
        "Delivery Delay (Days)",
        "Delay Reason / Comments",
        "Rework Count",
        "Rework Reason",
        "Continuing/New",
        "Public or Private",
        "ACM / Archival Date"
    )
    $col = @{}
    for ($i = 0; $i -lt $headers.Count; $i++) {
        $col[$headers[$i]] = $i + 1
        $tr.Cells.Item(2, $i + 1).Value2 = $headers[$i]
    }

    $inputNames = @(
        "Project / Engagement Name",
        "Unique Identifier",
        "Client Legal Entity",
        "Project Type",
        "Engagement Job Code",
        "Engagement Period",
        "ERP Platform",
        "Business Area KPI Distribution",
        "CI Delivery Lead",
        "Primary Analyst",
        "Secondary Analyst",
        "Overall Project Status",
        "Engagement Type (New/Recurring)",
        "Step 1 - Data Validation Status",
        "Step 2 - Data Cleansing Status",
        "Step 3 - Data Upload Status",
        "Step 4 - KPI Execution Status",
        "KPIs Delivered",
        "Target Delivery Date",
        "Request Initiation Date",
        "CI Acknowledged",
        "Initial Delivery Date",
        "Final Delivery Date",
        "Dashboard Delivered",
        "Business Areas Count",
        "Data Volume",
        "Files Processed",
        "Delivery Delay (Days)",
        "Delay Reason / Comments",
        "Rework Count",
        "Rework Reason",
        "Public or Private",
        "ACM / Archival Date"
    )
    $inputSet = @{}
    foreach ($n in $inputNames) { $inputSet[$n] = $true }

    $headerRange = $tr.Range($tr.Cells.Item(2, 1), $tr.Cells.Item(2, $headers.Count))
    $headerRange.Font.Bold = $true
    $headerRange.Font.Name = "Calibri"
    $headerRange.Font.Size = 10
    $headerRange.WrapText = $true
    $headerRange.HorizontalAlignment = $xlCenter
    $headerRange.VerticalAlignment = $xlCenter
    $headerRange.Borders.LineStyle = $thin
    $tr.Rows.Item(2).RowHeight = 36

    for ($i = 0; $i -lt $headers.Count; $i++) {
        $cell = $tr.Cells.Item(2, $i + 1)
        if ($inputSet.ContainsKey($headers[$i])) {
            $cell.Interior.Color = $gold
            $cell.Font.Color = $goldFont
        } else {
            $cell.Interior.Color = $blue
            $cell.Font.Color = $white
        }
    }

    $endAddr = $tr.Cells.Item(1, $headers.Count).Address($false, $false)
    $tr.Range("A1:$endAddr").Merge() | Out-Null
    $tr.Range("A1").Value2 = "Peeli heading = aap bharo. Neeli heading = automatic. Nayi engagement pehli khaali Project Name par likho. Status, dates, KPI, delay aur rework yahin update karo. Baaki 4 step sheets aur Summary khud badalte hain."
    $tr.Range("A1").Font.Color = $white
    $tr.Range("A1").Font.Bold = $true
    $tr.Range("A1").Font.Name = "Calibri"
    $tr.Range("A1").Font.Size = 12
    $tr.Range("A1").Interior.Color = $navy
    $tr.Range("A1").WrapText = $true
    $tr.Range("A1").VerticalAlignment = $xlCenter
    $tr.Rows.Item(1).RowHeight = 34

    function LookupFormula([string]$returnCol) {
        return ('=IF(OR(B3="",D3=""),"",IFERROR(XLOOKUP(D3,''Legal Entity Details''!$A$2:$A$200,''Legal Entity Details''!${0}$2:${0}$200,""),""))' -f $returnCol)
    }

    $tr.Cells.Item(3, $col["Sno"]).Formula = '=IF(B3="","",COUNTA($B$3:B3))'
    $tr.Cells.Item(3, $col["Office location"]).Formula = (LookupFormula "J")
    $tr.Cells.Item(3, $col["Region"]).Formula = (LookupFormula "K")
    $tr.Cells.Item(3, $col["Service line"]).Formula = (LookupFormula "B")
    $tr.Cells.Item(3, $col["Industry / sector"]).Formula = (LookupFormula "C")
    $tr.Cells.Item(3, $col["Engagement Team POC"]).Formula = (LookupFormula "D")
    $tr.Cells.Item(3, $col["POC Email"]).Formula = (LookupFormula "E")
    $tr.Cells.Item(3, $col["Engagement Manager"]).Formula = (LookupFormula "F")
    $tr.Cells.Item(3, $col["Manager Email"]).Formula = (LookupFormula "G")
    $tr.Cells.Item(3, $col["Engagement Partner"]).Formula = (LookupFormula "H")
    $tr.Cells.Item(3, $col["Partner Email"]).Formula = (LookupFormula "I")
    $tr.Cells.Item(3, $col["Continuing/New"]).Formula = (LookupFormula "L")
    $ownerFormula = '=IF(B3="","",U3)'
    foreach ($ownerName in @(
            "Step 1 - Data Validation Owner",
            "Step 2 - Data Cleansing Owner",
            "Step 3 - Data Upload Owner",
            "Step 4 - KPI Execution Owner"
        )) {
        $tr.Cells.Item(3, $col[$ownerName]).Formula = $ownerFormula
    }

    $formulaCols = @(
        "Sno", "Office location", "Region", "Service line", "Industry / sector",
        "Engagement Team POC", "POC Email", "Engagement Manager", "Manager Email",
        "Engagement Partner", "Partner Email", "Continuing/New",
        "Step 1 - Data Validation Owner", "Step 2 - Data Cleansing Owner",
        "Step 3 - Data Upload Owner", "Step 4 - KPI Execution Owner"
    )
    foreach ($name in $formulaCols) {
        $c = $col[$name]
        $src = $tr.Cells.Item(3, $c)
        $dest = $tr.Range($tr.Cells.Item(3, $c), $tr.Cells.Item(302, $c))
        $src.AutoFill($dest) | Out-Null
        $dest.Font.Color = $blue
        $dest.Font.Name = "Calibri"
        $dest.Font.Size = 11
    }

    $tr.Range("AH3:AL302").NumberFormat = "DD-MMM-YYYY"
    foreach ($numName in @(
            "KPIs Delivered", "Dashboard Delivered", "Business Areas Count", "Data Volume",
            "Files Processed", "Delivery Delay (Days)", "Rework Count"
        )) {
        $c = $col[$numName]
        $tr.Range($tr.Cells.Item(3, $c), $tr.Cells.Item(302, $c)).NumberFormat = "0"
    }

    function Unlock-Inputs {
        foreach ($name in $inputNames) {
            $c = $col[$name]
            $rng = $tr.Range($tr.Cells.Item(3, $c), $tr.Cells.Item(302, $c))
            $rng.Font.Name = "Calibri"
            $rng.Font.Size = 11
            $rng.Font.Color = (Ole 0 0 0)
        }
    }
    Unlock-Inputs

    # Example engagement (yellow cells are typed; blue cells stay formulas)
    function Put($header, $value) {
        $cell = $tr.Cells.Item(3, [int]$col[$header])
        if ($value -is [int] -or $value -is [long] -or $value -is [double]) {
            $cell.Value2 = [double]$value
        } else {
            $cell.Value2 = [string]$value
        }
    }
    Put "Project / Engagement Name" "EXAMPLE Project (clear this row)"
    Put "Unique Identifier" "1EXAMPLE"
    Put "Client Legal Entity" "EXAMPLE Client Pvt Ltd"
    Put "Project Type" "Stat"
    Put "Engagement Job Code" "DEMO-0001"
    Put "Engagement Period" "Apr'26-Mar'27"
    Put "ERP Platform" "Tally"
    Put "Business Area KPI Distribution" "General Ledger"
    Put "CI Delivery Lead" "Demo Lead"
    Put "Primary Analyst" "Demo Analyst"
    Put "Secondary Analyst" "Demo Support"
    Put "Overall Project Status" "Done"
    Put "Engagement Type (New/Recurring)" "New"
    Put "Step 1 - Data Validation Status" "Done"
    Put "Step 2 - Data Cleansing Status" "Done"
    Put "Step 3 - Data Upload Status" "Done"
    Put "Step 4 - KPI Execution Status" "Done"
    Put "KPIs Delivered" 3
    Put "Dashboard Delivered" 1
    Put "Business Areas Count" 1
    Put "Data Volume" 100
    Put "Files Processed" 2
    Put "Delivery Delay (Days)" 0
    Put "Rework Count" 0
    function Put-Date($header, [datetime]$date) {
        $serial = $date.ToOADate().ToString([System.Globalization.CultureInfo]::InvariantCulture)
        $tr.Cells.Item(3, [int]$col[$header]).Formula = $serial
    }
    Put-Date "Target Delivery Date" ([datetime]"2026-09-30")
    Put-Date "Request Initiation Date" ([datetime]"2026-07-01")
    Put-Date "CI Acknowledged" ([datetime]"2026-07-05")
    Put-Date "Initial Delivery Date" ([datetime]"2026-08-01")
    Put-Date "Final Delivery Date" ([datetime]"2026-08-20")

    foreach ($name in $inputNames) {
        $tr.Cells.Item(3, $col[$name]).Interior.Color = $inputFill
    }

    function Add-ListValidation($range, $named) {
        $range.Validation.Delete()
        $range.Validation.Add(3, 1, 1, $named) | Out-Null
        $range.Validation.IgnoreBlank = $true
        $range.Validation.InCellDropdown = $true
        $range.Validation.ShowError = $true
        $range.Validation.ErrorTitle = "List"
        $range.Validation.ErrorMessage = "List mein se value chuno."
    }
    Add-ListValidation $tr.Range("E3:E302") "=ProjectTypeList"
    Add-ListValidation $tr.Range($tr.Cells.Item(3, $col["CI Delivery Lead"]), $tr.Cells.Item(302, $col["CI Delivery Lead"])) "=DeliveryLeadList"
    Add-ListValidation $tr.Range($tr.Cells.Item(3, $col["Primary Analyst"]), $tr.Cells.Item(302, $col["Primary Analyst"])) "=AnalystList"
    Add-ListValidation $tr.Range("W3:W302") "=StatusList"
    Add-ListValidation $tr.Range("X3:X302") "=EngTypeList"
    Add-ListValidation $tr.Range("Z3:Z302") "=StatusList"
    Add-ListValidation $tr.Range("AB3:AB302") "=StatusList"
    Add-ListValidation $tr.Range("AD3:AD302") "=StatusList"
    Add-ListValidation $tr.Range("AF3:AF302") "=StatusList"

    function Add-StatusFormat($range, [string]$value, $fill, $font, [bool]$boldWhite) {
        $fc = $range.FormatConditions.Add(1, 3, $value)
        $fc.Interior.Color = $fill
        $fc.Font.Color = $font
        $fc.Font.Bold = $true
    }
    $statusRange = $tr.Range("W3:W302,Z3:Z302,AB3:AB302,AD3:AD302,AF3:AF302")
    Add-StatusFormat $statusRange "Yet to be picked" (Ole 255 230 180) (Ole 128 80 0) $false
    Add-StatusFormat $statusRange "WIP" $wipFill $white $true
    Add-StatusFormat $statusRange "Done" $greenFill $greenFont $false
    Add-StatusFormat $statusRange "Dormant" $dormFill $white $true
    Add-StatusFormat $statusRange "Not Applicable" (Ole 214 220 228) (Ole 89 89 89) $false
    Add-StatusFormat $statusRange "On Hold" $pendingFill $pendingFont $false
    Add-StatusFormat $statusRange "Dropped" $dropFill $dropFont $false

    $missing = $tr.Range("C3:C302").FormatConditions.Add(2, [Type]::Missing, '=AND($B3<>"",C3="")')
    $missing.Interior.Color = (Ole 255 199 206)
    $missingD = $tr.Range("D3:D302").FormatConditions.Add(2, [Type]::Missing, '=AND($B3<>"",D3="")')
    $missingD.Interior.Color = (Ole 255 199 206)
    $missingU = $tr.Range("U3:U302").FormatConditions.Add(2, [Type]::Missing, '=AND($B3<>"",U3="")')
    $missingU.Interior.Color = (Ole 255 199 206)

    $tr.Range($tr.Cells.Item(2, 1), $tr.Cells.Item(302, $headers.Count)).AutoFilter() | Out-Null
    $tr.Activate()
    $excel.ActiveWindow.FreezePanes = $false
    $tr.Range("A3").Select() | Out-Null
    $excel.ActiveWindow.FreezePanes = $true
    $tr.Application.ActiveWindow.Zoom = 100

    $widthMap = @{
        "Sno" = 8
        "Project / Engagement Name" = 40
        "Unique Identifier" = 28
        "Client Legal Entity" = 36
        "Project Type" = 14
        "Engagement Job Code" = 55
        "Office location" = 16
        "Region" = 12
        "Service line" = 16
        "Industry / sector" = 22
        "Engagement Period" = 18
        "ERP Platform" = 14
        "Business Area KPI Distribution" = 30
        "Engagement Team POC" = 22
        "POC Email" = 32
        "Engagement Manager" = 22
        "Manager Email" = 32
        "Engagement Partner" = 22
        "Partner Email" = 32
        "CI Delivery Lead" = 18
        "Primary Analyst" = 18
        "Secondary Analyst" = 18
        "Overall Project Status" = 22
        "Engagement Type (New/Recurring)" = 26
        "Step 1 - Data Validation Owner" = 16
        "Step 1 - Data Validation Status" = 14
        "Step 2 - Data Cleansing Owner" = 16
        "Step 2 - Data Cleansing Status" = 14
        "Step 3 - Data Upload Owner" = 16
        "Step 3 - Data Upload Status" = 14
        "Step 4 - KPI Execution Owner" = 16
        "Step 4 - KPI Execution Status" = 14
        "KPIs Delivered" = 16
        "Target Delivery Date" = 18
        "Request Initiation Date" = 20
        "CI Acknowledged" = 18
        "Initial Delivery Date" = 18
        "Final Delivery Date" = 18
        "Dashboard Delivered" = 18
        "Business Areas Count" = 18
        "Data Volume" = 14
        "Files Processed" = 16
        "Delivery Delay (Days)" = 18
        "Delay Reason / Comments" = 28
        "Rework Count" = 14
        "Rework Reason" = 24
        "Continuing/New" = 16
        "Public or Private" = 18
        "ACM / Archival Date" = 22
    }
    foreach ($name in $headers) { $tr.Columns.Item($col[$name]).ColumnWidth = $widthMap[$name] }

    $tr.PageSetup.Orientation = 2
    $tr.PageSetup.Zoom = $false
    $tr.PageSetup.FitToPagesWide = 1
    $tr.PageSetup.FitToPagesTall = $false
    $tr.PageSetup.PaperSize = 8

    # ---------- Stage sheets ----------
    function Build-Stage([string]$sheetName, [string]$ownerCol, [string]$statusCol) {
        $ws = Sheet $sheetName
        $ws.Range("A1:E1").Merge() | Out-Null
        $ws.Range("A1").Value2 = "Yeh sheet automatic hai. Yahan mat likho. Owner aur Status Project Tracker par update karo."
        $ws.Range("A1").Font.Italic = $true
        $ws.Range("A1").Font.Color = $navy
        $ws.Range("A1").VerticalAlignment = $xlCenter
        $stageHeaders = @("Unique Identifier", "S.No", "Project Name", "Resource", "Status")
        for ($c = 0; $c -lt $stageHeaders.Count; $c++) {
            $cell = $ws.Cells.Item(2, $c + 1)
            $cell.Value2 = $stageHeaders[$c]
            $cell.Font.Bold = $true
            $cell.Font.Color = $goldFont
            $cell.Interior.Color = $gold
            $cell.HorizontalAlignment = $xlCenter
        }
        $ws.Rows.Item(2).RowHeight = 22
        $formula = @"
=IFERROR(FILTER(HSTACK('Project Tracker'!`$$ownerCol`$3:`$$ownerCol`$302,'Project Tracker'!`$A`$3:`$A`$302,'Project Tracker'!`$B`$3:`$B`$302,'Project Tracker'!`$$statusCol`$3:`$$statusCol`$302,'Project Tracker'!`$Z`$3:`$Z`$302),'Project Tracker'!`$B`$3:`$B`$302<>""),"")
"@
        # placeholder replaced below
        return $ws
    }

    function Set-StageFormula($ws, [string]$ownerLetter, [string]$statusLetter) {
        $pairs = @(
            @("A", "C"),
            @("B", "A"),
            @("C", "B"),
            @("D", $ownerLetter),
            @("E", $statusLetter)
        )
        foreach ($pair in $pairs) {
            if ($pair[0] -eq "A" -or $pair[0] -eq "D" -or $pair[0] -eq "E") {
                $formula = '=IFERROR(IF(FILTER(''Project Tracker''!${0}$3:${0}$302,''Project Tracker''!$B$3:$B$302<>"")=0,"",FILTER(''Project Tracker''!${0}$3:${0}$302,''Project Tracker''!$B$3:$B$302<>"")),"")' -f $pair[1]
            } else {
                $formula = '=IFERROR(FILTER(''Project Tracker''!${0}$3:${0}$302,''Project Tracker''!$B$3:$B$302<>""),"")' -f $pair[1]
            }
            $ws.Range("$($pair[0])3").Formula2 = $formula
        }
        $ws.Columns.Item(1).ColumnWidth = 28
        $ws.Columns.Item(2).ColumnWidth = 10
        $ws.Columns.Item(3).ColumnWidth = 42
        $ws.Columns.Item(4).ColumnWidth = 20
        $ws.Columns.Item(5).ColumnWidth = 14
        $ws.Range("A2:E2").Borders.LineStyle = $thin
        $ws.Activate()
        $excel.ActiveWindow.FreezePanes = $false
        $ws.Range("A3").Select() | Out-Null
        $excel.ActiveWindow.FreezePanes = $true
    }

    # Resource column letters: Y AA AC AE ; status Z AB AD AF
    Set-StageFormula (Sheet "Data Sanity") "Y" "Z"
    Set-StageFormula (Sheet "Data Cleansing") "AA" "AB"
    Set-StageFormula (Sheet "Data Upload") "AC" "AD"
    Set-StageFormula (Sheet "KPI Execution") "AE" "AF"

    foreach ($stageName in @("Data Sanity", "Data Cleansing", "Data Upload", "KPI Execution")) {
        $ws = Sheet $stageName
        $ws.Range("A1:E1").Merge() | Out-Null
        $ws.Range("A1").Value2 = "Yeh sheet automatic hai. Yahan mat likho. Owner aur Status Project Tracker par update karo."
        $ws.Range("A1").Font.Italic = $true
        $ws.Range("A1").Font.Color = $navy
        $ws.Rows.Item(1).RowHeight = 20
        $stageHeaders = @("Unique Identifier", "S.No", "Project Name", "Resource", "Status")
        for ($c = 0; $c -lt $stageHeaders.Count; $c++) {
            $cell = $ws.Cells.Item(2, $c + 1)
            $cell.Value2 = $stageHeaders[$c]
            $cell.Font.Bold = $true
            $cell.Font.Color = $goldFont
            $cell.Interior.Color = $gold
            $cell.HorizontalAlignment = $xlCenter
        }
        $st = $ws.Range("E3:E302")
        Add-StatusFormat $st "Yet to be picked" (Ole 255 230 180) (Ole 128 80 0) $false
        Add-StatusFormat $st "WIP" $wipFill $white $true
        Add-StatusFormat $st "Done" $greenFill $greenFont $false
        Add-StatusFormat $st "Dormant" $dormFill $white $true
        Add-StatusFormat $st "Not Applicable" (Ole 214 220 228) (Ole 89 89 89) $false
        Add-StatusFormat $st "On Hold" $pendingFill $pendingFont $false
        Add-StatusFormat $st "Dropped" $dropFill $dropFont $false
    }

    # ---------- Summary ----------
    $sum = Sheet "Summary"
    $sum.Range("A1").Value2 = "Summary"
    $sum.Range("A1").Font.Size = 22
    $sum.Range("A1").Font.Bold = $true
    $sum.Range("A1").Font.Color = $navy
    $sum.Range("A2").Value2 = "Yeh numbers Project Tracker se khud aate hain. Sirf un rows ko ginna jata hai jinka Project Name bhara hai."
    $sum.Range("A2").Font.Italic = $true

    $cardLabels = @("Projects", "Delivered", "WIP", "Dropped", "Dormant", "Other", "KPIs")
    $cardFills = @($navy, $greenFill, $wipFill, $dropFill, $dormFill, (Ole 255 230 153), (Ole 47 84 150))
    $cardFonts = @($white, $greenFont, $white, $dropFont, $white, $pendingFont, $white)
    for ($i = 0; $i -lt $cardLabels.Count; $i++) {
        $cell = $sum.Cells.Item(4, $i + 1)
        $cell.Value2 = $cardLabels[$i]
        $cell.Font.Bold = $true
        $cell.Font.Color = $cardFonts[$i]
        $cell.Interior.Color = $cardFills[$i]
        $cell.HorizontalAlignment = $xlCenter
        $sum.Columns.Item($i + 1).ColumnWidth = 16
    }
    $sum.Range("A5").Formula = '=COUNTA(''Project Tracker''!$B$3:$B$302)'
    $sum.Range("B5").Formula = '=COUNTIFS(''Project Tracker''!$B$3:$B$302,"?*",''Project Tracker''!$W$3:$W$302,"Done")'
    $sum.Range("C5").Formula = '=COUNTIFS(''Project Tracker''!$B$3:$B$302,"?*",''Project Tracker''!$W$3:$W$302,"WIP")'
    $sum.Range("D5").Formula = '=COUNTIFS(''Project Tracker''!$B$3:$B$302,"?*",''Project Tracker''!$W$3:$W$302,"Dropped")'
    $sum.Range("E5").Formula = '=COUNTIFS(''Project Tracker''!$B$3:$B$302,"?*",''Project Tracker''!$W$3:$W$302,"Dormant")'
    $sum.Range("F5").Formula = '=A5-B5-C5-D5-E5'
    $sum.Range("G5").Formula = '=SUMPRODUCT((''Project Tracker''!$B$3:$B$302<>"")*(''Project Tracker''!$AG$3:$AG$302))'
    $sum.Range("A5:G5").Font.Size = 20
    $sum.Range("A5:G5").Font.Bold = $true
    $sum.Range("A5:G5").HorizontalAlignment = $xlCenter
    $sum.Range("A5:G5").Interior.Color = $cardFill
    $sum.Rows.Item(5).RowHeight = 32

    $personHeaders = @(
        "Primary Resource", "Projects", "Delivered", "WIP", "Dropped", "Dormant", "Other", "Number of KPIs", "Secondary Resource Count"
    )
    for ($c = 0; $c -lt $personHeaders.Count; $c++) {
        $cell = $sum.Cells.Item(8, $c + 1)
        $cell.Value2 = $personHeaders[$c]
        $cell.Font.Bold = $true
        $cell.Font.Color = $white
        $cell.Interior.Color = $navy
        $cell.WrapText = $true
        $cell.HorizontalAlignment = $xlCenter
    }
    $sum.Rows.Item(8).RowHeight = 30
    $sum.Columns.Item(1).ColumnWidth = 22
    $sum.Range("A7").Value2 = "Resource wise"
    $sum.Range("A7").Font.Bold = $true
    $sum.Range("A7").Font.Size = 14
    $sum.Range("A7").Font.Color = $navy

    $sum.Range("A9").Formula2 = '=IFERROR(UNIQUE(FILTER(''Project Tracker''!$U$3:$U$302,(''Project Tracker''!$B$3:$B$302<>"")*(''Project Tracker''!$U$3:$U$302<>""))),"")'
    $sum.Range("B9").Formula = '=IF(A9="","",COUNTIFS(''Project Tracker''!$U$3:$U$302,A9,''Project Tracker''!$B$3:$B$302,"?*"))'
    $sum.Range("C9").Formula = '=IF(A9="","",COUNTIFS(''Project Tracker''!$U$3:$U$302,A9,''Project Tracker''!$B$3:$B$302,"?*",''Project Tracker''!$W$3:$W$302,"Done"))'
    $sum.Range("D9").Formula = '=IF(A9="","",COUNTIFS(''Project Tracker''!$U$3:$U$302,A9,''Project Tracker''!$B$3:$B$302,"?*",''Project Tracker''!$W$3:$W$302,"WIP"))'
    $sum.Range("E9").Formula = '=IF(A9="","",COUNTIFS(''Project Tracker''!$U$3:$U$302,A9,''Project Tracker''!$B$3:$B$302,"?*",''Project Tracker''!$W$3:$W$302,"Dropped"))'
    $sum.Range("F9").Formula = '=IF(A9="","",COUNTIFS(''Project Tracker''!$U$3:$U$302,A9,''Project Tracker''!$B$3:$B$302,"?*",''Project Tracker''!$W$3:$W$302,"Dormant"))'
    $sum.Range("G9").Formula = '=IF(A9="","",B9-C9-D9-E9-F9)'
    $sum.Range("H9").Formula = '=IF(A9="","",SUMPRODUCT((''Project Tracker''!$U$3:$U$302=A9)*(''Project Tracker''!$B$3:$B$302<>"")*(''Project Tracker''!$AG$3:$AG$302)))'
    $sum.Range("I9").Formula = '=IF(A9="","",COUNTIFS(''Project Tracker''!$U$3:$U$302,A9,''Project Tracker''!$B$3:$B$302,"?*",''Project Tracker''!$V$3:$V$302,"?*"))'
    $sum.Range("B9:I9").AutoFill($sum.Range("B9:I40")) | Out-Null

    $sum.Range("I4").Value2 = "Status colours"
    $sum.Range("I4").Font.Bold = $true
    $legend = @(
        @("Yet to be picked", (Ole 255 230 180), (Ole 128 80 0)),
        @("WIP", $wipFill, $white),
        @("Done", $greenFill, $greenFont),
        @("Dormant", $dormFill, $white),
        @("Not Applicable", (Ole 214 220 228), (Ole 89 89 89)),
        @("On Hold", $pendingFill, $pendingFont),
        @("Dropped", $dropFill, $dropFont)
    )
    for ($i = 0; $i -lt $legend.Count; $i++) {
        $cell = $sum.Cells.Item(5 + $i, 9)
        $cell.Value2 = $legend[$i][0]
        $cell.Interior.Color = $legend[$i][1]
        $cell.Font.Color = $legend[$i][2]
        $cell.Font.Bold = $true
        $cell.HorizontalAlignment = $xlCenter
    }
    $sum.Columns.Item(9).ColumnWidth = 16
    $sum.Range("I13").Value2 = "Other = Yet to be picked, Not Applicable, On Hold, ya khali status."
    $sum.Range("I11").Font.Italic = $true

    # ---------- Add Engagement form ----------
    $form = Sheet "Add Engagement"
    $form.Columns.Item(1).ColumnWidth = 42
    $form.Columns.Item(2).ColumnWidth = 55
    $form.Columns.Item(3).ColumnWidth = 62
    $form.Range("A1:C1").Merge() | Out-Null
    $form.Range("A1").Value2 = "Nayi engagement yahan likho"
    $form.Range("A1").Font.Size = 20
    $form.Range("A1").Font.Bold = $true
    $form.Range("A1").Font.Color = $navy
    $form.Range("A2:C2").Merge() | Out-Null
    $form.Range("A2").Value2 = "Peeli cells bharo, Excel file band karo, phir Add-Engagement.bat par double-click karo. Khali Unique Identifier automatic ban jayega. Overall Status WIP set hoga. Neeli columns Legal Entity se khud aayenge."
    $form.Range("A2").WrapText = $true
    $form.Rows.Item(2).RowHeight = 36

    function SectionRow([int]$row, [string]$text) {
        $r = $form.Range("A${row}:C${row}")
        $r.Merge() | Out-Null
        $form.Cells.Item($row, 1).Value2 = $text
        $form.Cells.Item($row, 1).Font.Bold = $true
        $form.Cells.Item($row, 1).Font.Color = $white
        $form.Cells.Item($row, 1).Interior.Color = $sectionFill
    }
    function FormField([int]$row, [string]$label, [string]$hint, [string]$rangeName) {
        $form.Cells.Item($row, 1).Value2 = $label
        $form.Cells.Item($row, 1).Font.Bold = $true
        $box = $form.Cells.Item($row, 2)
        $box.Interior.Color = $formFill
        $box.Borders.LineStyle = $thin
        $form.Cells.Item($row, 3).Value2 = $hint
        $form.Cells.Item($row, 3).Font.Italic = $true
        $form.Cells.Item($row, 3).Font.Color = (Ole 89 89 89)
        $wb.Names.Add($rangeName, "='Add Engagement'!`$B`$$row") | Out-Null
    }

    SectionRow 4 "ZAROORI"
    FormField 5 "Project / Engagement Name" "Jaise JLL, Unifi, Karam Safety" "In_Project"
    FormField 6 "Unique Identifier" "Khali chhodo to automatic, jaise 18Karam Safety" "In_Unique"
    FormField 7 "Client Legal Entity" "Legal Entity Details jaisa exact naam" "In_Client"
    FormField 8 "Primary Analyst" "Step owners is naam se banenge" "In_Primary"

    SectionRow 10 "ENGAGEMENT DETAILS"
    FormField 11 "Project Type" "Stat ya Review" "In_ProjectType"
    FormField 12 "Engagement Job Code" "Jaise 7.5-UNIFI/8694-OTA..." "In_JobCode"
    FormField 13 "Engagement Period" "Jaise Apr'25-Mar'26" "In_Period"
    FormField 14 "ERP Platform" "Tally, SAP, ya khali" "In_ERP"
    FormField 15 "Business Area KPI Distribution" "Jaise General Ledger" "In_BusinessArea"
    FormField 16 "Engagement Type (New/Recurring)" "New ya Recurring" "In_EngType"
    FormField 17 "Secondary Analyst" "Optional" "In_Secondary"
    FormField 18 "CI Delivery Lead" "Optional" "In_CILead"

    SectionRow 20 "LOG  -  khali chhodo to Legal Entity se aa jayega"
    FormField 21 "Engagement Manager" "Optional override" "In_Manager"
    FormField 22 "Manager Email" "Optional override" "In_ManagerEmail"
    FormField 23 "Engagement Partner" "Optional override" "In_Partner"
    FormField 24 "Partner Email" "Optional override" "In_PartnerEmail"
    FormField 25 "Engagement Team POC" "Optional override" "In_POC"
    FormField 26 "POC Email" "Optional override" "In_POCEmail"

    SectionRow 28 "DATES  -  optional"
    FormField 29 "Target Delivery Date" "Jaise 30-Sep-2026" "In_Target"
    FormField 30 "Request Initiation Date" "Jaise 01-Jul-2026" "In_Request"
    $form.Range("B29:B30").NumberFormat = "DD-MMM-YYYY"
    $form.Range("B11").Validation.Add(3, 1, 1, "=ProjectTypeList") | Out-Null
    $form.Range("B11").Validation.InCellDropdown = $true
    $form.Range("B16").Validation.Add(3, 1, 1, "=EngTypeList") | Out-Null
    $form.Range("B16").Validation.InCellDropdown = $true
    $form.Range("B8").Validation.Add(3, 1, 1, "=AnalystList") | Out-Null
    $form.Range("B8").Validation.InCellDropdown = $true
    $form.Range("B18").Validation.Add(3, 1, 1, "=DeliveryLeadList") | Out-Null
    $form.Range("B18").Validation.InCellDropdown = $true

    $form.Range("A32").Value2 = "Tracker mein abhi engagements"
    $form.Range("A32").Font.Bold = $true
    $form.Range("B32").Formula = '=COUNTA(''Project Tracker''!$B$3:$B$302)'
    $form.Range("B32").Font.Size = 16
    $form.Range("B32").Font.Bold = $true
    $form.Range("B32").Interior.Color = $cardFill

    $form.Range("A33").Value2 = "Result"
    $form.Range("A33").Font.Bold = $true
    $form.Range("B33:C34").Merge() | Out-Null
    $form.Range("B33").Interior.Color = (Ole 221 235 247)
    $form.Range("B33").WrapText = $true
    $form.Range("B33").VerticalAlignment = $xlCenter
    $form.Rows.Item(33).RowHeight = 22
    $form.Rows.Item(34).RowHeight = 22
    $wb.Names.Add("In_Message", "='Add Engagement'!`$B`$33") | Out-Null

    $logHeads = @("Time", "Project", "Unique Identifier", "Client", "Primary Analyst", "Result")
    for ($c = 0; $c -lt $logHeads.Count; $c++) {
        $cell = $form.Cells.Item(36, $c + 1)
        $cell.Value2 = $logHeads[$c]
        $cell.Font.Bold = $true
        $cell.Font.Color = $white
        $cell.Interior.Color = $navy
    }
    $form.Range("A35").Value2 = "Add log"
    $form.Range("A35").Font.Bold = $true
    $form.Range("A35").Font.Size = 14
    $form.Range("A35").Font.Color = $navy

    # ---------- Instructions ----------
    $how = Sheet "Kaise use karein"
    $how.Columns.Item(1).ColumnWidth = 3
    $how.Columns.Item(2).ColumnWidth = 28
    $how.Columns.Item(3).ColumnWidth = 110
    $how.Range("B2").Value2 = "Audit Engagement Tracker"
    $how.Range("B2").Font.Size = 26
    $how.Range("B2").Font.Bold = $true
    $how.Range("B2").Font.Color = $navy
    $how.Range("B3:C3").Merge() | Out-Null
    $how.Range("B3").Value2 = "Nayi engagement ek baar likho. Client ke log, office, region, industry, aur step owners khud bharenge. Charo step sheets aur Summary khud update honge."
    $how.Range("B3").WrapText = $true
    $how.Rows.Item(3).RowHeight = 36

    $how.Range("B5").Value2 = "Peeli heading"
    $how.Range("B5").Interior.Color = $gold
    $how.Range("B5").Font.Bold = $true
    $how.Range("B5").HorizontalAlignment = $xlCenter
    $how.Range("C5").Value2 = "Yeh aap bharte ho: project, client, job code, analyst, status, dates, KPI, delay, rework."
    $how.Range("B6").Value2 = "Neeli heading"
    $how.Range("B6").Interior.Color = $blue
    $how.Range("B6").Font.Color = $white
    $how.Range("B6").Font.Bold = $true
    $how.Range("B6").HorizontalAlignment = $xlCenter
    $how.Range("C6").Value2 = "Yeh automatic hai: Sno, office, region, service line, industry, POC, manager, partner, emails, Continuing/New, aur 4 step owners."

    $lines = @(
        @(8, "1. Pehle Legal Entity", "Legal Entity Details mein har client ki ek line bharo: naam, service line, industry, POC, manager, partner, office, region, New/Continuing. Example row clear kar sakte ho."),
        @(9, "2. Phir engagement", "Project Tracker par EXAMPLE ke neeche pehli khaali Project Name par naya kaam likho. Sirf peeli heading wale cells bharo."),
        @(10, "3. Naam match", "Client Legal Entity ka naam Legal Entity sheet ke pehle column jaisa hona chahiye. Spelling same ho to neeli cells khud bhar jayengi."),
        @(11, "4. Unique Identifier", "Khud likho, jaise 1JLL ya 17Oravel Madecomfy JE. Khali chhodo to cell laal ho jayegi. Form se add karoge to ye automatic banta hai."),
        @(12, "5. Status yahin", "Overall status aur har step ka status Project Tracker par dropdown se badlo: Yet to be picked, WIP, Done, Dormant, Not Applicable, On Hold, Dropped. Step sheets par mat likho."),
        @(13, "6. Form (optional)", "Add Engagement ki peeli cells bharo. Is Excel file ko band karo. Folder mein Add-Engagement.bat par double-click karo. Nayi line Project Tracker par aa jayegi."),
        @(14, "7. Example hatana", "EXAMPLE row ke peele cells clear kar do (Project Name, Client, Analyst, Status, dates). Poori row delete karne ki zaroorat nahi."),
        @(15, "8. Step 3", "Purani file mein Data Upload ka step bhi Step 2 likha tha. Yahan uska naam Step 3 - Data Upload hai, taaki 4 steps alag dikhen."),
        @(16, "9. Capacity", "Is file mein 300 engagements tak ki jagah hai. Uske baad bata dena, limit badha denge."),
        @(17, "10. ET file se", "ET wali Excel Inbox folder mein rakho, ya Import-ET.bat par drop karo. Audit_Tracker band hona chahiye. Project, client, job code, partner, manager, POC, period, ERP khud add ho jayenge. Primary Analyst baad mein bharo.")
    )
    foreach ($line in $lines) {
        $how.Cells.Item($line[0], 2).Value2 = $line[1]
        $how.Cells.Item($line[0], 2).Font.Bold = $true
        $how.Cells.Item($line[0], 2).VerticalAlignment = $xlCenter
        $how.Cells.Item($line[0], 2).Interior.Color = $cardFill
        $how.Cells.Item($line[0], 3).Value2 = $line[2]
        $how.Cells.Item($line[0], 3).WrapText = $true
        $how.Cells.Item($line[0], 3).VerticalAlignment = $xlCenter
        $how.Rows.Item($line[0]).RowHeight = 48
    }

    $how.Range("B18").Value2 = "Sheets"
    $how.Range("B18").Font.Bold = $true
    $how.Range("B18").Font.Size = 16
    $how.Range("B18").Font.Color = $navy
    $sheetHelp = @(
        @("Project Tracker", "Asli kaam yahan hota hai. Nayi line aur status yahin."),
        @("Data Sanity", "Step 1 ka view. Project Tracker se khud banta hai."),
        @("Data Cleansing", "Step 2 ka view."),
        @("Data Upload", "Step 3 ka view."),
        @("KPI Execution", "Step 4 ka view."),
        @("Summary", "Kitne projects Delivered, WIP, Dropped, Dormant hain, resource wise."),
        @("Legal Entity Details", "Client master. Ek client ek baar. Phir har engagement par khud lagta hai."),
        @("Add Engagement", "Optional form. Bat file se Project Tracker mein line add hoti hai."),
        @("Lists", "Chhupi hui sheet. Status ya region badalne par right-click karke Unhide karo.")
    )
    for ($i = 0; $i -lt $sheetHelp.Count; $i++) {
        $how.Cells.Item(19 + $i, 2).Value2 = $sheetHelp[$i][0]
        $how.Cells.Item(19 + $i, 2).Font.Bold = $true
        $how.Cells.Item(19 + $i, 3).Value2 = $sheetHelp[$i][1]
        $how.Rows.Item(19 + $i).RowHeight = 22
    }

    # Tab colors
    (Sheet "Kaise use karein").Tab.Color = $navy
    (Sheet "Add Engagement").Tab.Color = $gold
    (Sheet "Project Tracker").Tab.Color = $blue
    (Sheet "Summary").Tab.Color = (Ole 0 128 0)
    (Sheet "Data Sanity").Tab.Color = (Ole 68 114 196)
    (Sheet "Data Cleansing").Tab.Color = (Ole 68 114 196)
    (Sheet "Data Upload").Tab.Color = (Ole 68 114 196)
    (Sheet "KPI Execution").Tab.Color = (Ole 192 80 77)
    (Sheet "Legal Entity Details").Tab.Color = (Ole 112 48 160)
    (Sheet "Lists").Visible = 0

    $how.Activate()
    $excel.ActiveWindow.DisplayGridlines = $false
    (Sheet "Summary").Activate()
    $excel.ActiveWindow.DisplayGridlines = $false
    (Sheet "Add Engagement").Activate()
    $excel.ActiveWindow.DisplayGridlines = $false
    (Sheet "Kaise use karein").Activate()

    $excel.CalculateFull()

    $checks = New-Object System.Collections.Generic.List[string]
    function Add-Check([string]$label, $text) { $checks.Add("$label = $text") }
    Add-Check "Office" $tr.Range("G3").Text
    Add-Check "Region" $tr.Range("H3").Text
    Add-Check "Service" $tr.Range("I3").Text
    Add-Check "Industry" $tr.Range("J3").Text
    Add-Check "POC" $tr.Range("N3").Text
    Add-Check "POCEmail" $tr.Range("O3").Text
    Add-Check "Manager" $tr.Range("P3").Text
    Add-Check "Partner" $tr.Range("R3").Text
    Add-Check "Owner1" $tr.Range("Y3").Text
    Add-Check "Owner3" $tr.Range("AC3").Text
    Add-Check "Sno" $tr.Range("A3").Text
    Add-Check "Continuing" $tr.Range("AU3").Text
    Add-Check "Projects" $sum.Range("A5").Text
    Add-Check "Delivered" $sum.Range("B5").Text
    Add-Check "KPIs" $sum.Range("G5").Text
    Add-Check "Resource" $sum.Range("A9").Text
    Add-Check "ResourceProjects" $sum.Range("B9").Text
    $sanity = Sheet "Data Sanity"
    Add-Check "SanityId" $sanity.Range("A3").Text
    Add-Check "SanitySno" $sanity.Range("B3").Text
    Add-Check "SanityName" $sanity.Range("C3").Text
    Add-Check "SanityResource" $sanity.Range("D3").Text
    Add-Check "SanityStatus" $sanity.Range("E3").Text
    $upload = Sheet "Data Upload"
    Add-Check "UploadResource" $upload.Range("D3").Text
    Add-Check "UploadStatus" $upload.Range("E3").Text
    Add-Check "FormulaG" $tr.Range("G3").Formula
    $checks | Set-Content -Path $resultPath -Encoding UTF8

    if (Test-Path $outPath) { Remove-Item $outPath -Force }
    $wb.SaveAs($outPath, 51)
    $saved = $true
    $wb.Close($true)
    $wb = $null
}
catch {
    $_ | Out-File -FilePath $resultPath -Encoding UTF8
    Write-Host $_
    exit 1
}
finally {
    try {
        if ($wb -ne $null) { $wb.Close($false) }
    } catch {}
    try {
        if ($excel -ne $null) {
            $excel.Quit()
            [System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null
        }
    } catch {}
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}

if ($saved) {
    Write-Host "SAVED $outPath"
} else {
    Write-Host "BUILD FAILED"
    exit 1
}
