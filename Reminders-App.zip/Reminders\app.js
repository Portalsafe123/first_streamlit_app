const STORAGE_KEY = "simple-reminders";
const notifiedKey = (id) => `notified-${id}`;

const form = document.getElementById("reminder-form");
const list = document.getElementById("reminder-list");
const status = document.getElementById("status");
const notifyBtn = document.getElementById("notify-btn");
const titleInput = document.getElementById("title");
const notesInput = document.getElementById("notes");
const dateInput = document.getElementById("date");
const timeInput = document.getElementById("time");
const sheet = document.getElementById("sheet");
const sheetBackdrop = document.getElementById("sheet-backdrop");
const openFormBtn = document.getElementById("open-form");
const cancelFormBtn = document.getElementById("cancel-form");
const clock = document.getElementById("clock");

let reminders = loadReminders();
let filter = "upcoming";

function loadReminders() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveReminders() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(reminders));
}

function dueAt(reminder) {
  return new Date(`${reminder.date}T${reminder.time}`);
}

function formatWhen(reminder) {
  const date = dueAt(reminder);
  return date.toLocaleString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function isOverdue(reminder) {
  return !reminder.done && dueAt(reminder).getTime() <= Date.now();
}

function matchesFilter(reminder) {
  if (filter === "all") return true;
  if (filter === "done") return reminder.done;
  if (filter === "overdue") return isOverdue(reminder);
  return !reminder.done && !isOverdue(reminder);
}

function render() {
  const visible = reminders
    .slice()
    .sort((a, b) => dueAt(a) - dueAt(b))
    .filter(matchesFilter);

  const counts = {
    upcoming: reminders.filter((item) => !item.done && !isOverdue(item)).length,
    overdue: reminders.filter(isOverdue).length,
    done: reminders.filter((item) => item.done).length,
  };

  status.textContent =
    reminders.length === 0
      ? "No reminders yet. Tap + to add one."
      : `${counts.upcoming} upcoming · ${counts.overdue} overdue · ${counts.done} done`;

  if (visible.length === 0) {
    list.innerHTML = `<li class="empty">Nothing in this list right now.</li>`;
    return;
  }

  list.innerHTML = visible
    .map((reminder) => {
      const overdue = isOverdue(reminder);
      return `
        <li class="item ${reminder.done ? "done" : ""}" data-id="${reminder.id}">
          <input type="checkbox" ${reminder.done ? "checked" : ""} aria-label="Mark done" />
          <div>
            <strong class="item-title">${escapeHtml(reminder.title)}</strong>
            <p class="when ${overdue ? "overdue" : ""}">${overdue ? "Overdue · " : ""}${escapeHtml(formatWhen(reminder))}</p>
            ${reminder.notes ? `<p class="notes">${escapeHtml(reminder.notes)}</p>` : ""}
            <div class="actions">
              <button type="button" class="done-btn">${reminder.done ? "Undo" : "Done"}</button>
              <button type="button" class="delete-btn">Delete</button>
            </div>
          </div>
        </li>
      `;
    })
    .join("");
}

function escapeHtml(value) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const title = titleInput.value.trim();
  const notes = notesInput.value.trim();
  const date = dateInput.value;
  const time = timeInput.value;
  if (!title || !date || !time) return;

  reminders.push({
    id: crypto.randomUUID(),
    title,
    notes,
    date,
    time,
    done: false,
    createdAt: Date.now(),
  });
  saveReminders();
  form.reset();
  setDefaultDateTime();
  closeSheet();
  render();
});

function openSheet() {
  sheet.hidden = false;
  sheetBackdrop.hidden = false;
  titleInput.focus();
}

function closeSheet() {
  sheet.hidden = true;
  sheetBackdrop.hidden = true;
}

openFormBtn.addEventListener("click", openSheet);
cancelFormBtn.addEventListener("click", closeSheet);
sheetBackdrop.addEventListener("click", closeSheet);

list.addEventListener("click", (event) => {
  const item = event.target.closest(".item");
  if (!item) return;
  const reminder = reminders.find((entry) => entry.id === item.dataset.id);
  if (!reminder) return;

  if (event.target.matches("input[type=checkbox]") || event.target.classList.contains("done-btn")) {
    reminder.done = !reminder.done;
    saveReminders();
    render();
  }

  if (event.target.classList.contains("delete-btn")) {
    reminders = reminders.filter((entry) => entry.id !== reminder.id);
    saveReminders();
    render();
  }
});

document.querySelectorAll(".filter").forEach((button) => {
  button.addEventListener("click", () => {
    filter = button.dataset.filter;
    document.querySelectorAll(".filter").forEach((item) => item.classList.toggle("is-active", item === button));
    render();
  });
});

notifyBtn.addEventListener("click", async () => {
  if (!("Notification" in window)) {
    notifyBtn.textContent = "Alerts not supported";
    return;
  }
  const permission = await Notification.requestPermission();
  notifyBtn.textContent = permission === "granted" ? "Alerts on" : "Alerts blocked";
});

function maybeNotify() {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  reminders.forEach((reminder) => {
    if (reminder.done || sessionStorage.getItem(notifiedKey(reminder.id))) return;
    if (dueAt(reminder).getTime() <= Date.now()) {
      new Notification(reminder.title, {
        body: reminder.notes || "This reminder is due now.",
      });
      sessionStorage.setItem(notifiedKey(reminder.id), "1");
    }
  });
}

function setDefaultDateTime() {
  const now = new Date();
  now.setMinutes(now.getMinutes() + 30);
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  dateInput.value = local.toISOString().slice(0, 10);
  timeInput.value = local.toISOString().slice(11, 16);
}

function updateClock() {
  clock.textContent = new Date().toLocaleTimeString(undefined, {
    hour: "numeric",
    minute: "2-digit",
  });
}

setDefaultDateTime();
updateClock();
render();
setInterval(() => {
  render();
  maybeNotify();
  updateClock();
}, 30000);

if ("Notification" in window && Notification.permission === "granted") {
  notifyBtn.textContent = "Alerts on";
}
